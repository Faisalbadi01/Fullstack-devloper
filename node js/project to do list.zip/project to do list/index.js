const express=require('express');
const port=1231;

const app=express();

app.use(express.urlencoded())

let data=[

    {
        id:1,
        name:"faisal",
        rollno:23,
        courses:"fullstack"
    },
    {
        id:2,
        name:"mayank",
        rollno:33,
        courses:"fullstack"
    }
]


app.set( 'view engine', 'ejs' ); 

app.get('/',(req,res)=>{

    res.render('form',{

        sub:data
    });
})



app.post('/insertdata',(req,res)=>{


let id=req.body.id;
let name=req.body.name;
let rollno=req.body.rollno;
let courses=req.body.courses;


let obj={


id:id,
name:name,
rollno:rollno,
courses:courses

}


data.push(obj);

 return res.redirect('back');

})


app.get('/deletedata',(req,res)=>{


    let id=req.query.id;


     let main=data.filter((val)=>{

        return val.id !=id;

    })


    data=main;

    return  res.redirect('back');

})


app.get('/editdata',(req,res)=>{


    let id=req.query.id;

    let mdata=data.filter((val)=>{


        return val.id==id;

    })

    return res.render('edit',{

        sdata:mdata[0]
    })


})




app.post("/updatedata",(req,res)=>{


    let id=req.body.id;


    let main=data.filter((val)=>{


        if (val.id==id) {
            val.id=req.body.id;
            val.name=req.body.name;
            val.rollno=req.body.rollno;
            val.courses=req.body.courses;
        }
        return val;
    })

    data=main;

    return res.redirect('/');


})



app.get('/alldeletedata',(req,res)=>{


data=[];

return res.redirect('/')

})







app.listen(port,(err)=>{

    if (err) 
    {
        console.log("server not start");   
    }
    else{
        console.log("server started at:-"+port);
    }
})