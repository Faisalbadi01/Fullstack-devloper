const express=require('express');

const port=9898;

const app=express();

const path=require('path');

app.use(express.static(path.join(__dirname, 'public')));

app.use(express.urlencoded())
const database=require('./config/database');

const table=require('./model/schema'); 
const data=require('./model/adminschema')

const nodemailer=require('nodemailer');

const otp=Math.floor(Math.random()*10000);

app.set("view engine" ,"ejs")




const session=require('express-session');

app.use(session({secret : "private-key"}));

const flash = require('connect-flash')

app.use(flash());







const  sendMail=async(req,res)=>{

    const transporter=nodemailer.createTransport({
    
        service: 'gmail',
         auth:{
    
            user:"faisalbadi57@gmail.com",
            pass:"ymlsdfyrzbowplto",
    
    
         },
    });
    
    const info=await transporter.sendMail({
    
        from:"faisalbadi57@gmail.com",
        to:req.body.email,
        subject:"opt",
        html:`${otp}`
    
    })
    res.redirect('login')
    
    }
      
      



    const verifiy =async(req,res)=>{

        let token=req.body.otp;


        if (token==otp) {

        let email=req.body.email;


let user = await table.findOne({email:email});

            let id=user.id;

            let password=req.body.newpassword;

            await table.findByIdAndUpdate(id,{password:password})

            
            res.redirect("log")
    
        }
        else{

            res.redirect("error")
        }
    }


    const logup =async(req,res)=>{

        let data= req.body;

        let exituser= await table.findOne({email:data.email});

        if (!exituser) {
            
            res.send("this is wrong user")
        }
        if (exituser.password != data.password) {
            res.send("this is wrong password")
        }
        else{
            res.redirect("/home")
        }



    }







app.get("/",(req,res)=>{


    res.render("resgistar")


})

app.get("/login",(req,res)=>{

    res.render("login")


})

app.get("/home",(req,res)=>{

    res.render('home')

})
app.get("/error",(req,res)=>{

    res.render('error')

})
app.get("/log",(req,res)=>{

    res.render('log',{info:req.flash("msg")})

})

app.post("/log",logup,(req,res)=>{


  
    req.flash("msg","password change Successfuly")
});
app.post("/otp",sendMail);

app.post("/insert",(req,res)=>{


    let data=req.body;

    table.create(data)

    res.redirect("/log")

})

app.get("/forgot",(req,res)=>{

res.render( "forgot");



})

app.post("/update",verifiy);

































app.get('/home',(req,res)=>{

    res.render('home')
    
    })
    
    app.get('/a',(req,res)=>{
    
        res.render('form')
    
    })
    
    
    
    app.post('/inserts',(req,res)=>{
    
    
        data.create({
    
            userName:req.body.userName,
            password:req.body.password,
            name:req.body.name,
            surname:req.body.surname,
            email:req.body.email,
            address:req.body.address,
            acceptTerms:req.body.acceptTerms,
            gender:req.body.gender
        }).then(()=>{
    
            console.log("successfully insert");
            return res.redirect('/home')
    
        })
    
       
    })
    app.get('/view',(req,res)=>{
    
    
        data.find({}).then((alldata)=>{
    
    
            res.render('table',{
    
                cvil:alldata
            })
    
        })
    
    })
    
    
    
    
    
    
    
    
    app.get('/delete',(req,res)=>{
    
    
        let id=req.query.id;
    
        data.findByIdAndDelete(id).then(()=>{
    
            res.redirect('/view')
        })
    })
    
    
    
    
    
    
    
    
    app.get('/edit',(req,res)=>{
    
        let id=req.query.id;
    
    
        data.findById(id).then((alldata)=>{
    
            res.render('edit',
            {
                edit:alldata
            }
            );
    
    
        })
    
       
    })
    
    
    app.post('/ubdate',(req,res)=>{
    
    let id=req.body.id;
    
    data.findByIdAndUpdate(id,{
    
    
        userName:req.body.userName,
        password:req.body.password,
        name : req.body.name,
        surname:req.body.surname,
        email:req.body.email,
        address:req.body.address,
        acceptTerms:req.body.acceptTerms,
        gender:req.body.gender
    
    }).then(()=>{
        console.log("data succesfully updated");
        return res.redirect("/view");
    })
    
    })
    
    
    








app.listen(port,()=>{

    console.log("server started at:-"+port);


})