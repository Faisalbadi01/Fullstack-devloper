const mongoose=require('mongoose');

mongoose.connect("mongodb://127.0.0.1/forgotpassword");


var db = mongoose.connection;

db.on('connected',()=>{

    console.log("databaase connected");


})


module.exports=db;

