const mongoose=require( 'mongoose');

const books=mongoose.Schema({


    name:{
        type:String, 
        required:true
    },
    author:{
        type:String, 
        required:true
    },
    phone:{
        type:String, 
        required:true
    },
    price:{
        type:String, 
        required:true
    }


})

const  book = module.exports = mongoose.model('Book',books);


module.exports=book;