const express=require('express');

const port=9898;

const app=express();
app.use(express.urlencoded());
const path=require( 'path' );

const db=require('./config/database');
const bookschema=require('./models/bookschema');


app.set("view engine","ejs");



app.get("/",(req,res)=>{


    res.render("add")

})
app.use('/',express.static(path.join(__dirname,'public')));


app.post('/insertdata',(req,res)=>{

bookschema.create({
    name:req.body.name,
    author:req.body.author,
    phone:req.body.phone,
    price:req.body.price

})
res.redirect('/')

})




app.get("/viewdata",(req,res)=>{


    bookschema.find({}).then((alldata)=>{

        res.render("our",{
            data:alldata
        })
    })

})



app.get("/delete",(req,res)=>{

let id=req.query.id;

bookschema.findByIdAndDelete(id).then(()=>{
   res.redirect('viewdata'); 
});

});
 
app.get('/edit',(req,res)=>{


    let id= req.query.id;

    bookschema.findById(id).then((alldata) =>{

        res.render("store",{

            edit:alldata
        })

})
})




app.post( "/update" , (req,res) => {
    let id=req.body.id;
    bookschema.findByIdAndUpdate(id,{
    
        name : req.body.name,
        author:req.body.author,
        phone:req.body.phone,
        price:req.body.price,
    }).then(()=>{
        console.log('data updated');
        
    
       return res.redirect("/viewdata");
    }); 
    
    });
    



app.get("/abt",(req,res)=>{

    res.render("abt")
})

app.get("/store",(req,res)=>{

    res.render("store")
})

app.get("/lib",(req,res)=>{

    res.render("lib")
})






app.listen(port,()=>{
    console.log("Server is running on:- " +port);
});

