const mongoose=require('mongoose');

mongoose.connect("mongodb://127.0.0.1/Store");

const db = mongoose.connection;

db.on('connected',()=>{


    console.log("Connected to the database");

})

module.exports=db;