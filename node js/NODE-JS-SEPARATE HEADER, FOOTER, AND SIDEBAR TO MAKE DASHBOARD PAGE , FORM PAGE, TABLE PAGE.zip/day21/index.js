const express=require('express');

const database=require('./config/database');

const data=require('./model/schema');


const port=9898;

const app=express();

const path=require( 'path' );

app.use(express.urlencoded());

app.use(express.static(path.join(__dirname, 'public')));


app.set("view engine",'ejs');

app.get('/',(req,res)=>{

res.render('index')

})

app.get('/a',(req,res)=>{

    res.render('form')

})



app.post('/insert',(req,res)=>{


    data.create({

        userName:req.body.userName,
        password:req.body.password,
        name:req.body.name,
        surname:req.body.surname,
        email:req.body.email,
        address:req.body.address,
        acceptTerms:req.body.acceptTerms,
        gender:req.body.gender
    }).then(()=>{

        console.log("successfully insert");
        return res.redirect('/')

    })

   
})
app.get('/view',(req,res)=>{


    data.find({}).then((alldata)=>{


        res.render('table',{

            cvil:alldata
        })

    })

})








app.get('/delete',(req,res)=>{


    let id=req.query.id;

    data.findByIdAndDelete(id).then(()=>{

        res.redirect('/view')
    })
})








app.get('/edit',(req,res)=>{

    let id=req.query.id;


    data.findById(id).then((alldata)=>{

        res.render('edit',
        {
            edit:alldata
        }
        );


    })

   
})


app.post('/update',(req,res)=>{

let id=req.body.id;

data.findByIdAndUpdate(id,{


    userName:req.body.userName,
    password:req.body.password,
    name : req.body.name,
    surname:req.body.surname,
    email:req.body.email,
    address:req.body.address,
    acceptTerms:req.body.acceptTerms,
    gender:req.body.gender

}).then(()=>{
    console.log("data succesfully updated");
    return res.redirect("/view");
})

})









app.listen(port,()=>{


    console.log("server started at:-"+port);

})