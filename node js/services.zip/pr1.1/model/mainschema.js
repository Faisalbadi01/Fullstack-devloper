const mongoose=require( 'mongoose');

const schema=mongoose.Schema({


    name:{
        type:String,
        required:true
    },
    
    number:{
        type:String,
        required:true
    },
   gender:{
        type:String,
        required:true
    },
    email:{
        type:String,
        required:true
    },
    pin:{
        type:String,
        required:true
    },
    img:{
        type:String,
        required:true
    },



})


const table=mongoose.model('table',schema);

module.exports=table; 