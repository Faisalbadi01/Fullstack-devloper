const express=require('express');


const session=require('express-session');

const passport=require('passport')
const route=express.Router();

const curdcontrol=require('../controllers/curdcontrol');

    const multer=require('multer');


    const storage=multer.diskStorage({


        destination:(req,file,cb)=>{


            cb(null,'uploads/')


        },
        filename:(req,file,cb)=>{
    
    
            cb(null,file.originalname)
        }


    })
  
    
    const upload=multer({storage:storage}).single('img');


route.get('/',curdcontrol.index);

route.get('/login',curdcontrol.login);

route.post('/sign',curdcontrol.sign);

route.post('/index',passport.authenticate('local'),curdcontrol.lg);

route.get('/add',curdcontrol.add);

route.post('/insert',upload,curdcontrol.insert)

route.get('/view',curdcontrol.view);

route.get('/delete',curdcontrol.alldelet);

route.get('/edit',curdcontrol.edit);

route.post('/update',upload,curdcontrol.update);

module.exports=route;